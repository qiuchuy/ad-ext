#pragma once
#include "mlir/IR/Value.h"

namespace ainl::ir {

mlir::Value compute_mean();

}