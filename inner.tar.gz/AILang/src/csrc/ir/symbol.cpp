#include "ir/symbol.h"

namespace ainl::ir {

Environment *env;
} // namespace ainl::ir