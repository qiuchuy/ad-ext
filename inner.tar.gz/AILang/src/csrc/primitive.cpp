#include "primitive.h"

#include <algorithm>
#include <cstddef>
#include <memory>
#include <numeric>
#include <stdexcept>

#include "array.h"
#include "ast/node_contract.h"
#include "ast/type_contract.h"
#include "ir/container.h"
#include "ir/function.h"
#include "ir/type.h"
#include "ir/value.h"
#include "ops.h"
#include "trace.h"
#include "transformation.h"
namespace ainl::core {

void UnaryPrimitive::eval(const std::vector<Array> &inputs,
                          std::vector<Array> &outputs) {
    eval(inputs, outputs[0]);
}

void UnaryPrimitive::evalCPU(const std::vector<Array> &inputs,
                             std::vector<Array> &outputs) {
    evalCPU(inputs, outputs[0]);
}

void UnaryPrimitive::jit(const std::vector<JITTracer> &inputs,
                         std::vector<JITTracer> &outputs) {
    jit(inputs, outputs[0]);
}

void UnaryPrimitive::jvp(const std::vector<JVPTracer> &inputs,
                         std::vector<JVPTracer> &outputs) {
    jvp(inputs, outputs[0]);
}

void IdentityPrimitive::eval(const std::vector<Array> &inputs, Array &output) {
    evalCPU(inputs, output);
}

void IdentityPrimitive::evalCPU(const std::vector<Array> &inputs,
                                Array &output) {
    if (inputs.size() != 1) {
        throw std::invalid_argument(
            "[IdentityPrimitive::evalCPU] expects exactly one input array.");
    }
    output.copyBySharing(inputs[0], 0, 0, inputs[0].shape());
}

void IdentityPrimitive::jit(const std::vector<JITTracer> &inputs,
                            JITTracer &output) {}

void IdentityPrimitive::jvp(const std::vector<JVPTracer> &inputs,
                            JVPTracer &output) {}

std::string IdentityPrimitive::toString() const { return "Identity"; }

void AddPrimitive::eval(const std::vector<Array> &inputs, Array &output) {
    evalCPU(inputs, output);
}



void AddPrimitive::jit(const std::vector<JITTracer> &inputs,
                       JITTracer &output) {
    if (inputs.size() != 2) {
        throw std::invalid_argument(
            "[AddPrimitive::jit] expects exactly two input tracers.");
    }
    auto input0 = inputs[0];
    auto input1 = inputs[1];
    std::vector<ir::TypePtr> inputType = {input0.value()->getType(),
                                          input1.value()->getType()};
    std::vector<ir::ValuePtr> inputValues = {input0.value(), input1.value()};
    // type inference
    auto outputType = ir::resolveContract("add", inputType);

    auto module = getTracedModule();

    // ir generation
    output.setValue(
        ir::resolveContract("add", module, outputType, inputValues));
    output.setTracer(unary<AddPrimitive>({input0.tracer(), input1.tracer()}));
}

void AddPrimitive::jvp(const std::vector<JVPTracer> &inputs,
                       JVPTracer &output) {}

std::string AddPrimitive::toString() const { return "Add"; }

void FlattenPrimitive::eval(const std::vector<Array> &inputs, Array &output) {
    evalCPU(inputs, output);
}

void FlattenPrimitive::evalCPU(const std::vector<Array> &inputs,
                               Array &output) {
    if (inputs.size() != 1) {
        throw std::invalid_argument(
            "[FlattenPrimitive::evalCPU] expects exactly one input array.");
    }

    auto input = inputs[0];
    auto inputShape = input.shape();
    auto size = std::accumulate(inputShape.begin(), inputShape.end(), 1,
                                std::multiplies<int>());
    output.copyBySharing(input, size, 0, {size});
}

void FlattenPrimitive::jit(const std::vector<JITTracer> &inputs,
                           JITTracer &output) {}

void FlattenPrimitive::jvp(const std::vector<JVPTracer> &inputs,
                           JVPTracer &output) {}

std::string FlattenPrimitive::toString() const { return "Flatten"; }

void FillPrimitive::eval(const std::vector<Array> &inputs, Array &output) {
    evalCPU(inputs, output);
}

void FillPrimitive::evalCPU(const std::vector<Array> &inputs, Array &output) {
    if (inputs.size() != 1) {
        throw std::invalid_argument(
            "[FillPrimitive::evalCPU] expects exactly one input array.");
    }

    auto input = inputs[0];
    auto inputShape = input.shape();
    auto size = std::accumulate(inputShape.begin(), inputShape.end(), 1,
                                std::multiplies<int>());
}

void FillPrimitive::jit(const std::vector<JITTracer> &inputs,
                        JITTracer &output) {}

void FillPrimitive::jvp(const std::vector<JVPTracer> &inputs,
                        JVPTracer &output) {}

std::string FillPrimitive::toString() const { return "Fill"; }

void SlicePrimitive::eval(const std::vector<Array> &inputs, Array &output) {
    evalCPU(inputs, output);
}

void SlicePrimitive::evalCPU(const std::vector<Array> &inputs, Array &output) {
    // Numpy style slice, see:
    // https://numpy.org/doc/stable/user/basics.indexing.html
    if (inputs.size() != 1) {
        throw std::invalid_argument(
            "[SlicePrimitive::evalCPU] expects exactly one input array.");
    }

    if (begin_.size() != end_.size() || begin_.size() != stride_.size()) {
        throw std::invalid_argument("[SlicePrimitive::evalCPU] begin, end and "
                                    "stride should have the same "
                                    "size.");
    }

    const auto input = inputs[0];
    size_t inputNdim = input.ndim();
    if (begin_.size() != inputNdim || end_.size() != inputNdim ||
        stride_.size() != inputNdim) {
        throw std::invalid_argument("[SlicePrimitive::evalCPU] begin, end and "
                                    "stride should have the same "
                                    "size as the input array.");
    }

    if (inputNdim == 0) {
        throw std::invalid_argument("[SlicePrimitive::evalCPU] Input array "
                                    "must have at least one dimension.");
    }
    auto inputShape = input.shape();

    // check input ranges: suppose input has shape (a, b, c)
    // then illegal slice ranges should be: [-a, a], [-b, b], [-c, c]
    for (size_t i = 0; i < inputNdim; i++) {
        if (begin_[i] < -inputShape[i] || begin_[i] > inputShape[i]) {
            throw std::invalid_argument(
                "[SlicePrimitive::evalCPU] Illegal slice "
                "range for input array.");
        }
    }

    for (size_t i = 0; i < inputNdim; i++) {
        if (end_[i] < -inputShape[i] || end_[i] > inputShape[i]) {
            throw std::invalid_argument(
                "[SlicePrimitive::evalCPU] Illegal slice "
                "range for input array.");
        }
    }

    // convert negative slice range into positive
    auto begin = begin_;
    for (size_t i = 0; i < begin.size(); i++) {
        if (begin[i] < 0) {
            begin[i] = inputShape[i] + begin[i];
        }
    }
    auto end = end_;
    for (size_t i = 0; i < end.size(); i++) {
        if (end[i] < 0) {
            end[i] = inputShape[i] + end[i];
        }
    }

    // calculate output shape from slice parameters and input shape
    std::vector<int> outputShape;
    for (size_t i = 0; i < inputShape.size(); i++) {
        outputShape.push_back((end[i] - begin[i]));
    }

    // calculate the offset, size of the output array
    auto size = input.itemsize();
    for (size_t i = 0; i < outputShape.size(); i++) {
        size *= outputShape[i];
    }

    auto offset = 0;
    for (size_t i = 0; i < inputShape.size(); i++) {
        auto dimOffset = 0;
        for (size_t j = i + 1; j < inputShape.size(); j++) {
            dimOffset += inputShape[j] * input.itemsize();
        }
        offset += begin[i] * dimOffset;
    }
    output.copyBySharing(input, size, offset, outputShape);
}

std::string SlicePrimitive::toString() const { return "Slice"; }

void SlicePrimitive::jit(const std::vector<JITTracer> &inputs,
                         JITTracer &output) {}

void SlicePrimitive::jvp(const std::vector<JVPTracer> &inputs,
                         JVPTracer &output) {}

void ReshapePrimitive::eval(const std::vector<Array> &inputs, Array &output) {
    evalCPU(inputs, output);
}

void ReshapePrimitive::evalCPU(const std::vector<Array> &inputs,
                               Array &output) {
    if (inputs.size() != 1) {
        throw std::invalid_argument(
            "[ReshapePrimitive::evalCPU] expects exactly one input array.");
    }

    auto input = inputs[0];
    auto inputShape = input.shape();
    auto size = std::accumulate(inputShape.begin(), inputShape.end(), 1,
                                std::multiplies<int>());
    if (std::accumulate(shape_.begin(), shape_.end(), 1,
                        std::multiplies<int>()) != size) {
        throw std::invalid_argument(
            "[ReshapePrimitive::evalCPU] The total number of elements in the "
            "input array must be the same as the total number of elements in "
            "the "
            "output array.");
    }

    output.copyBySharing(input, size, 0, shape_);
}

void ReshapePrimitive::jit(const std::vector<JITTracer> &inputs,
                           JITTracer &output) {}

void ReshapePrimitive::jvp(const std::vector<JVPTracer> &inputs,
                           JVPTracer &output) {
    if (inputs.size() != 1) {
        throw std::invalid_argument(
            "[ReshapePrimitive::jvp] expects exactly one input tracer.");
    }
    auto input = inputs[0];
    output.setPrimal(unary<ReshapePrimitive>({input.primal()}, shape_));
    output.setTangent(unary<ReshapePrimitive>({input.tangent()}, shape_));
}

std::string ReshapePrimitive::toString() const { return "Reshape"; }

void TransposePrimitive::eval(const std::vector<Array> &inputs, Array &output) {
    evalCPU(inputs, output);
}



void TransposePrimitive::jit(const std::vector<JITTracer> &inputs,
                             JITTracer &output) {
    if (inputs.size() != 1) {
        throw std::invalid_argument(
            "[TransposePrimitive::jit] expects exactly one input tracer.");
    }

    auto input = inputs[0];
    std::vector<ir::TypePtr> inputType = {input.value()->getType()};
    std::vector<ir::ValuePtr> inputValues = {input.value()};
    auto outputType = ir::resolveContract("transpose", inputType);

    auto module = getTracedModule();
    output.setValue(
        ir::resolveContract("transpose", module, outputType, inputValues));
    output.setTracer(unary<TransposePrimitive>({input.tracer()}));
}

void TransposePrimitive::jvp(const std::vector<JVPTracer> &inputs,
                             JVPTracer &output) {
    if (inputs.size() != 1) {
        throw std::invalid_argument(
            "[TransposePrimitive::jvp] expects exactly one input tracer.");
    }
    auto input = inputs[0];
    output.setPrimal(unary<TransposePrimitive>({input.primal()}));
    output.setTangent(unary<TransposePrimitive>({input.tangent()}));
}

std::string TransposePrimitive::toString() const { return "Transpose"; }

void MatMulPrimitive::eval(const std::vector<Array> &inputs, Array &output) {
    evalCPU(inputs, output);
}



void MatMulPrimitive::jit(const std::vector<JITTracer> &inputs,
                          JITTracer &output) {
    if (inputs.size() != 2) {
        throw std::invalid_argument(
            "[MatMulPrimitive::jit] expects exactly two input tracers.");
    }
    auto input0 = inputs[0];
    auto input1 = inputs[1];
    std::vector<ir::TypePtr> inputType = {input0.value()->getType(),
                                          input1.value()->getType()};
    std::vector<ir::ValuePtr> inputValues = {input0.value(), input1.value()};

    // type inference
    auto outputType = ir::resolveContract("matmul", inputType);

    auto module = getTracedModule();

    // ir generation
    output.setValue(
        ir::resolveContract("matmul", module, outputType, inputValues));
    output.setTracer(
        unary<MatMulPrimitive>({input0.tracer(), input1.tracer()}));
}

void MatMulPrimitive::jvp(const std::vector<JVPTracer> &inputs,
                          JVPTracer &output) {}

std::string MatMulPrimitive::toString() const { return "MatMul"; }
// AsType
void AsTypePrimitive::eval(const std::vector<Array> &inputs, Array &output) {
    evalCPU(inputs, output);
}

void AsTypePrimitive::jit(const std::vector<JITTracer> &inputs,
                          JITTracer &output) {}
void AsTypePrimitive::jvp(const std::vector<JVPTracer> &inputs,
                          JVPTracer &output) {}

std::string AsTypePrimitive::toString() const { return "AsType"; }
// broadcast
void BroadcastPrimitive::eval(const std::vector<Array> &inputs, Array &output) {
    evalCPU(inputs, output);
}

void BroadcastPrimitive::jit(const std::vector<JITTracer> &inputs,
                             JITTracer &output) {
    // if (inputs.size() != 2) {
    //     throw std::invalid_argument(
    //         "[BroadcastPrimitive::jit] expects exactly one input tracers.");
    // }
    // auto input = inputs[0];
    // // literal or attribute
    // // std::vector<ir::ValuePtr> outputShape_;
    // // to be confirmed. literal value has no Array's achivement.so put all
    // // dims into inputValues.
    // std::vector<ir::ValuePtr> inputValues = {input.value()};

    // for (const auto &dim : shape_) {
    //     inputValues.push_back(ir::Literal::create(dim));
    // }

    // std::vector<ir::TypePtr> inputType = {input.value()->getType()};

    // auto outputType = ir::resolveContract("broadcast", inputType);

    // auto module = getTracedModule();

    // output.setValue(
    //     ir::resolveContract("broadcast", module, outputType, inputValues));
    // output.setTracer(
    //     unary<BroadcastPrimitive>({input.tracer()}, shape_)); // Args...args
}
void BroadcastPrimitive::jvp(const std::vector<JVPTracer> &inputs,
                             JVPTracer &output) {}
std::string BroadcastPrimitive::toString() const { return "Broadcast"; }

// max
void MaximumPrimitive::eval(const std::vector<Array> &inputs, Array &output) {
    evalCPU(inputs, output);
}
void MaximumPrimitive::evalCPU(const std::vector<Array> &inputs,
                               Array &output) {}
void MaximumPrimitive::jit(const std::vector<JITTracer> &inputs,
                           JITTracer &output) {}
void MaximumPrimitive::jvp(const std::vector<JVPTracer> &inputs,
                           JVPTracer &output) {}

std::string MaximumPrimitive::toString() const { return "Max"; }
// min
void MinimumPrimitive::eval(const std::vector<Array> &inputs, Array &output) {
    evalCPU(inputs, output);
}

void MinimumPrimitive::evalCPU(const std::vector<Array> &inputs,
                               Array &output) {}
void MinimumPrimitive::jit(const std::vector<JITTracer> &inputs,
                           JITTracer &output) {}
void MinimumPrimitive::jvp(const std::vector<JVPTracer> &inputs,
                           JVPTracer &output) {}

std::string MinimumPrimitive::toString() const { return "Min"; }

// Multiply
void MultiplyPrimitive::eval(const std::vector<Array> &inputs, Array &out) {
    evalCPU(inputs, out);
}
void MultiplyPrimitive::evalCPU(const std::vector<Array> &inputs,
                                Array &output) {}
void MultiplyPrimitive::jit(const std::vector<JITTracer> &inputs,
                            JITTracer &output) {}
void MultiplyPrimitive::jvp(const std::vector<JVPTracer> &inputs,
                            JVPTracer &output) {}

std::string MultiplyPrimitive::toString() const { return "multiply"; }

// substract
void SubtractPrimitive::eval(const std::vector<Array> &inputs, Array &output) {
    evalCPU(inputs, output);
}
void SubtractPrimitive::jit(const std::vector<JITTracer> &inputs,
                            JITTracer &output) {}
void SubtractPrimitive::evalCPU(const std::vector<Array> &inputs,
                                Array &output) {}

void SubtractPrimitive::jvp(const std::vector<JVPTracer> &inputs,
                            JVPTracer &output) {}

std::string SubtractPrimitive::toString() const { return "Sub"; }

// SquarePrimitive
void SquarePrimitive::eval(const std::vector<Array> &inputs, Array &output) {
    evalCPU(inputs, output);
}
void SquarePrimitive::evalCPU(const std::vector<Array> &inputs, Array &output) {
}
void SquarePrimitive::jit(const std::vector<JITTracer> &inputs,
                          JITTracer &output) {}
void SquarePrimitive::jvp(const std::vector<JVPTracer> &inputs,
                          JVPTracer &output) {}

std::string SquarePrimitive::toString() const { return "Square"; }

// Sqrt
void SqrtPrimitive::eval(const std::vector<Array> &inputs, Array &output) {
    evalCPU(inputs, output);
}
void SqrtPrimitive::evalCPU(const std::vector<Array> &inputs, Array &output) {}

void SqrtPrimitive::jit(const std::vector<JITTracer> &inputs,
                        JITTracer &output) {}
void SqrtPrimitive::jvp(const std::vector<JVPTracer> &inputs,
                        JVPTracer &output) {}

std::string SqrtPrimitive::toString() const { return "Sqrt"; }
// sigmoid
void SigmoidPrimitive::eval(const std::vector<Array> &inputs, Array &out) {
    evalCPU(inputs, out);
}
void SigmoidPrimitive::evalCPU(const std::vector<Array> &inputs,
                               Array &output) {}
void SigmoidPrimitive::jit(const std::vector<JITTracer> &inputs,
                           JITTracer &output) {}
void SigmoidPrimitive::jvp(const std::vector<JVPTracer> &inputs,
                           JVPTracer &output) {}

std::string SigmoidPrimitive::toString() const { return "Sigmoid"; }

// Reduce
void ReducePrimitive::eval(const std::vector<Array> &inputs, Array &out) {
    evalCPU(inputs, out);
}
void ReducePrimitive::evalCPU(const std::vector<Array> &inputs, Array &output) {
}
void ReducePrimitive::jit(const std::vector<JITTracer> &inputs,
                          JITTracer &output) {}
void ReducePrimitive::jvp(const std::vector<JVPTracer> &inputs,
                          JVPTracer &output) {}

std::string ReducePrimitive::toString() const {}

// convolution
void ConvolutionPrimitive::eval(const std::vector<Array> &inputs, Array &out) {
    evalCPU(inputs, out);
}
void ConvolutionPrimitive::evalCPU(const std::vector<Array> &inputs,
                                   Array &output) {}

void ConvolutionPrimitive::jit(const std::vector<JITTracer> &inputs,
                               JITTracer &output) {
    if (inputs.size() != 2) {
        throw std::invalid_argument(
            "[Convolution::jit] expects exactly two input tracers.one is "
            "input, and the other is weight.");
    }
    auto input = inputs[0];
    auto weight = inputs[1];
    std::vector<ir::TypePtr> inputType = {input.value()->getType(),
                                          weight.value()->getType()};
    std::vector<ir::ValuePtr> inputValues = {input.value(), weight.value()};

    // type inference
    auto outputType = ir::resolveContract("convolution", inputType);

    auto module = getTracedModule();

    // ir generation
    output.setValue(
        ir::resolveContract("convolution", module, outputType, inputValues));
    output.setTracer(
        unary<ConvolutionPrimitive>({input.tracer(), weight.tracer()}));
}
void ConvolutionPrimitive::jvp(const std::vector<JVPTracer> &inputs,
                               JVPTracer &output) {}
std::string ConvolutionPrimitive::toString() const { return "Conv"; }
// Relu

void ReluPrimitive::eval(const std::vector<Array> &inputs, Array &output) {
    evalCPU(inputs, output);
}

void ReluPrimitive::evalCPU(const std::vector<Array> &inputs, Array &output) {
    if (inputs.size() != 1) {
        throw std::invalid_argument(
            "[ReluPrimitive::evalCPU] expects exactly one input array.");
    }
    auto input = inputs[0];
    // TODO
}

void ReluPrimitive::jit(const std::vector<JITTracer> &inputs,
                        JITTracer &output) {
    if (inputs.size() != 1) {
        throw std::invalid_argument(
            "[ReluPrimitive::jit] expects exactly one input tracer.");
    }

    auto input = inputs[0];
    std::vector<ir::TypePtr> inputType = {input.value()->getType()};
    std::vector<ir::ValuePtr> inputValues = {input.value()};
    auto outputType = ir::resolveContract("relu", inputType);
    auto module = getTracedModule();
    output.setValue(
        ir::resolveContract("relu", module, outputType, inputValues));
    output.setTracer(unary<ReluPrimitive>({input.tracer()}));
}

void ReluPrimitive::jvp(const std::vector<JVPTracer> &inputs,
                        JVPTracer &output) {}

std::string ReluPrimitive::toString() const { return "relu"; }
// BatchnormInferencePrimitive

void BatchnormInferencePrimitive::eval(const std::vector<Array> &inputs,
                                       Array &output) {
    evalCPU(inputs, output);
}

void BatchnormInferencePrimitive::evalCPU(const std::vector<Array> &inputs,
                                          Array &output) {
    if (inputs.size() != 1) {
        throw std::invalid_argument("[BatchnormInferencePrimitive::evalCPU] "
                                    "expects exactly one input array.");
    }
    auto input = inputs[0];
    throw std::invalid_argument(
                    "[batchnorm infernece prmitive] not implemnet yet.");
}

void BatchnormInferencePrimitive::jit(const std::vector<JITTracer> &inputs,
                                      JITTracer &output) {
    if (inputs.size() != 1) {
        throw std::invalid_argument("[BatchnormInferencePrimitive::jit] "
                                    "expects exactly one input tracer.");
    }
    auto input = inputs[0];
    std::vector<ir::TypePtr> inputType = {input.value()->getType()};
    std::vector<ir::ValuePtr> inputValues = {input.value()};
    auto outputType = ir::resolveContract("batchnorm2d", inputType);
    auto module = getTracedModule();
    output.setValue(
        ir::resolveContract("batchnorm2d", module, outputType, inputValues));
    output.setTracer(unary<BatchnormInferencePrimitive>({input.tracer()}));
}

void BatchnormInferencePrimitive::jvp(const std::vector<JVPTracer> &inputs,
                                      JVPTracer &output) {}

std::string BatchnormInferencePrimitive::toString() const {
    return "BatchnormInference";
}
// GetElementsNumberPrimitive
void GetElementsNumberPrimitive::eval(const std::vector<Array> &inputs,
                                      Array &out) {
    evalCPU(inputs, out);
}
void GetElementsNumberPrimitive::evalCPU(const std::vector<Array> &inputs,
                                         Array &output) {}
void GetElementsNumberPrimitive::jit(const std::vector<JITTracer> &inputs,
                                     JITTracer &output) {}
void GetElementsNumberPrimitive::jvp(const std::vector<JVPTracer> &inputs,
                                     JVPTracer &output) {}

std::string GetElementsNumberPrimitive::toString() const {
    return "GetElementsNumber";
}

// loop
void LoopPrimitive::eval(const std::vector<Array> &inputs,
                         std::vector<Array> &output) {
    evalCPU(inputs, output);
}

void LoopPrimitive::evalCPU(const std::vector<Array> &inputs,
                            std::vector<Array> &output) {
    auto inits = convertTracerSharedPtrVector(inputs);
    while (1) {
        auto cond = cond_(inits);
        if (auto array = asTracer<Array>(cond)) {
            if (!array->item<bool>()) {
                break;
            }
        }
        inits = body_(inits);
    }
    output = convertTracerVector<Array>(inits);
}

void LoopPrimitive::jit(const std::vector<JITTracer> &inputs,
                        std::vector<JITTracer> &outputs) {
    std::vector<ir::TypePtr> inputsTypes;
    // for loop primitive, we enforce the type of output variables match the
    // type of input variables at the top level
    for (auto &input : inputs) {
        inputsTypes.push_back(input.value()->getType());
    }
    auto outputTypes = ir::TupleType::createUnnamedTuple(inputsTypes);
    std::vector<ir::ValuePtr> inputValues;
    for (auto &input : inputs) {
        inputValues.push_back(input.value());
    }

    auto inits = convertTracerSharedPtrVector(inputs);
    std::vector<std::shared_ptr<Tracer>> tracers;
    for (const auto &input : inputs) {
        tracers.push_back(input.tracer());
    }

    auto module = getTracedModule();
    auto savedModule = *module;

    // jit cond_ and body_ respectively
    auto jitCond = cond_;
    auto condWrapper =
        [jitCond](const std::vector<std::shared_ptr<Tracer>> &inits) {
            auto cond = jitCond(inits);
            return std::vector<std::shared_ptr<Tracer>>{cond};
        };

    auto condModule = ainl::core::jit(condWrapper, "cond", "", tracers);

    auto bodyModule = ainl::core::jit(body_, "body", "", tracers);

    *module = savedModule;

    inputValues.push_back(ir::ALModule::createModuleValue(*condModule));
    inputValues.push_back(ir::ALModule::createModuleValue(*bodyModule));

    auto whileOp = ir::asValueType<ir::WhileOp>(
        ir::resolveContract("loop", module, outputTypes, inputValues));

    getCurrentTrace()->unpack(inits);
    auto outputTracers = op<LoopPrimitive>(inits, cond_, body_);
    for (size_t i = 0; i < whileOp->getOutputValues().size(); i++) {
        outputs[i].setValue(whileOp->getOutputValues()[i]);
        outputs[i].setTracer(outputTracers[i]);
    }
}

void LoopPrimitive::jvp(const std::vector<JVPTracer> &inputs,
                        std::vector<JVPTracer> &output) {}

std::string LoopPrimitive::toString() const { return "Loop"; }

void ComparePrimitive::eval(const std::vector<Array> &inputs, Array &output) {
    evalCPU(inputs, output);
}

void ComparePrimitive::evalCPU(const std::vector<Array> &inputs,
                               Array &output) {
    if (inputs.size() != 2) {
        throw std::invalid_argument("[ComparePrimitive::evalCPU] expects "
                                    "exactly two input arrays.");
    }

    auto lhs = inputs[0];
    auto rhs = inputs[1];
    auto dtype1 = inputs[0].dtype();
    auto dtype2 = inputs[1].dtype();
    if (dtype1.type != dtype2.type) {
        throw std::invalid_argument("[ComparePrimitive::evalCPU] input arrays "
                                    "must have the same dtype.");
    }
    if (lhs.shape() != rhs.shape()) {
        throw std::invalid_argument("[ComparePrimitive::evalCPU] input arrays "
                                    "must have the same shape.");
    }

    switch (dtype1.type) {
    case Dtype::DataType::BoolType: {
        compare<bool>(lhs, rhs, output);
        break;
    }
    case Dtype::DataType::Int8Type: {
        compare<int8_t>(lhs, rhs, output);
        break;
    }
    case Dtype::DataType::Int16Type: {
        compare<int16_t>(lhs, rhs, output);
        break;
    }
    case Dtype::DataType::Int32Type: {
        compare<int32_t>(lhs, rhs, output);
        break;
    }
    case Dtype::DataType::Int64Type: {
        compare<int64_t>(lhs, rhs, output);
        break;
    }
    case Dtype::DataType::Float32Type: {
        compare<float>(lhs, rhs, output);
        break;
    }
    case Dtype::DataType::Float64Type: {
        compare<double>(lhs, rhs, output);
        break;
    }
    }
}

void ComparePrimitive::jit(const std::vector<JITTracer> &inputs,
                           JITTracer &output) {
    auto input0 = inputs[0];
    auto input1 = inputs[1];
    std::vector<ir::TypePtr> inputType = {input0.value()->getType(),
                                          input1.value()->getType()};
    std::vector<ir::ValuePtr> inputValues = {input0.value(), input1.value()};

    std::string compareOp = ir::compareOpString[static_cast<size_t>(op_)];

    auto outputType = ir::resolveContract(compareOp, inputType);

    auto module = getTracedModule();

    output.setValue(
        ir::resolveContract(compareOp, module, outputType, inputValues));

    std::vector<std::shared_ptr<Tracer>> tracers;
    for (const auto &input : inputs) {
        tracers.push_back(input.tracer());
    }

    output.setTracer(unary<ComparePrimitive>(tracers, op_));
}

void ComparePrimitive::jvp(const std::vector<JVPTracer> &inputs,
                           JVPTracer &output) {}

std::string ComparePrimitive::toString() const { return "Compare"; }

void IfPrimitive::eval(const std::vector<Array> &inputs,
                       std::vector<Array> &output) {
    evalCPU(inputs, output);
}

void IfPrimitive::evalCPU(const std::vector<Array> &inputs,
                          std::vector<Array> &output) {}

void IfPrimitive::jit(const std::vector<JITTracer> &inputs,
                      std::vector<JITTracer> &outputs) {
    auto ifCond = inputs.front();
    std::vector<ir::TypePtr> inputTypes = {ifCond.value()->getType()};
    std::vector<ir::ValuePtr> inputValues = {ifCond.value()};

    auto module = getTracedModule();

    auto trueBranchWrapper = std::function<std::vector<std::shared_ptr<Tracer>>(
        const std::vector<std::shared_ptr<Tracer>> &)>(
        [&](const std::vector<std::shared_ptr<Tracer>> &inits) {
            return trueBranch();
        });
    auto falseBranchWrapper =
        std::function<std::vector<std::shared_ptr<Tracer>>(
            const std::vector<std::shared_ptr<Tracer>> &)>(
            [&](const std::vector<std::shared_ptr<Tracer>> &inits) {
                return falseBranch();
            });

    auto trueBranchModule =
        ainl::core::jit(trueBranchWrapper, "trueBranch", "", {});
    auto falseBranchModule =
        ainl::core::jit(falseBranchWrapper, "falseBranch", "", {});
    inputValues.push_back(ir::ALModule::createModuleValue(*trueBranchModule));
    inputValues.push_back(ir::ALModule::createModuleValue(*falseBranchModule));

    inputTypes.push_back(trueBranchModule->getReturnType());
    inputTypes.push_back(falseBranchModule->getReturnType());
    auto outputType = ir::resolveContract("ifop", inputTypes);

    auto ifOp = ir::asValueType<ir::IfOp>(
        ir::resolveContract("ifop", module, outputType, inputValues));

    auto inits = convertTracerSharedPtrVector(inputs);
    getCurrentTrace()->unpack(inits);
    auto outputTracers = op<IfPrimitive>(inits, trueBranch, falseBranch);

    for (size_t i = 0; i < ifOp->getOutputValues().size(); i++) {
        outputs[i].setValue(ifOp->getOutputValues()[i]);
        outputs[i].setTracer(outputTracers[i]);
    }
}

void IfPrimitive::jvp(const std::vector<JVPTracer> &inputs,
                      std::vector<JVPTracer> &output) {}

std::string IfPrimitive::toString() const { return "If"; }

} // namespace ainl::core
